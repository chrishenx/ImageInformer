package model;

import java.awt.image.BufferedImage;
import java.awt.Color;
import java.util.HashMap;

public class ImageProcessor {
  private BufferedImage image;
  
  
  public ImageProcessor(BufferedImage image) {
    this.image = image;
  }
  
  public HashMap<Color, Integer> countColors() {
    if (image == null) return null;
    HashMap<Color, Integer> colorsCount = new HashMap<>();
    int width = image.getWidth();
    int height = image.getHeight();
    for (int i = 0; i < width; i++) {
      for (int j = 0; j < height; j++) {
        Color rgb = new Color(image.getRGB(i, j));
        if (colorsCount.containsKey(rgb)) {
          colorsCount.put(rgb, colorsCount.get(rgb) + 1);
        } else {
          colorsCount.put(rgb, 0);
        }
      }
    }
    return colorsCount;
  }
  
  public double calculateEntropy() {
    HashMap<Color, Integer> colorsCount = countColors();
    int numPixels = image.getWidth() * image.getHeight();
    System.out.println("Number of pixels: " + numPixels);
    double entropy = 0;
    for (Integer colorOcurrences : colorsCount.values()) {
      System.out.println("Color ocurrences: " + colorOcurrences);
      double probability = colorOcurrences / numPixels; 
      if (probability > 0) {
        entropy += log2(1 / probability) * probability;
      }
    }
    return Math.floor(entropy);
  }
  
  public static double log2(double val) {
    return Math.log10(val) / Math.log10(2);
  }
  
  

}
